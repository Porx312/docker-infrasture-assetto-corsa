import fs from 'fs';
import path from 'path';
import { createWriteStream, createReadStream } from 'fs';
import { pipeline } from 'stream/promises';
import unzipper from 'unzipper';
import '../config/loadEnv.js';

const DEFAULT_CONTENT_BASE_PATH = '/home/jose/assetto-install/assetto/content';

function contentBasePath(): string {
  return process.env.CONTENT_PATH || DEFAULT_CONTENT_BASE_PATH;
}

export type ContentType = 'cars' | 'tracks' | 'weather';

export interface ContentItem {
    name: string;
    path: string;
    size: number;
    modified: Date;
    isDirectory: boolean;
}

const ALLOWED_ROOT_EXTENSIONS: Record<ContentType, string[]> = {
    cars: ['.kn5', '.acd', '.ini', '.zip', '.bank'],
    tracks: ['.kn5', '.acd', '.ini', '.zip', '.bank'],
    weather: ['.ini', '.zip'],
};

function getContentDir(type: ContentType): string {
    return path.join(contentBasePath(), type);
}

export function resolveSafeContentPath(contentDir: string, relativePath: string): string | null {
    const normalized = relativePath.replace(/\\/g, '/').replace(/^\/+/, '');
    if (!normalized || normalized.includes('..')) {
        return null;
    }

    const targetPath = path.join(contentDir, normalized);
    const resolvedContent = path.resolve(contentDir);
    const resolvedTarget = path.resolve(targetPath);
    const contentPrefix = `${resolvedContent}${path.sep}`;

    if (resolvedTarget !== resolvedContent && !resolvedTarget.startsWith(contentPrefix)) {
        return null;
    }

    return resolvedTarget;
}

export function isAllowedUpload(relativePath: string, type: ContentType): boolean {
    const normalized = relativePath.replace(/\\/g, '/');
    if (normalized.includes('/')) {
        return true;
    }

    const ext = path.extname(normalized).toLowerCase();
    if (!ext) {
        return false;
    }

    return (ALLOWED_ROOT_EXTENSIONS[type] ?? []).includes(ext);
}

async function ensureContentDir(type: ContentType): Promise<string> {
    const contentDir = getContentDir(type);
    await fs.promises.mkdir(contentDir, { recursive: true });
    return contentDir;
}

export async function listContent(type: ContentType): Promise<ContentItem[]> {
    const contentDir = getContentDir(type);

    if (!fs.existsSync(contentDir)) {
        return [];
    }

    const entries = await fs.promises.readdir(contentDir, { withFileTypes: true });
    const items: ContentItem[] = [];

    for (const entry of entries) {
        const fullPath = path.join(contentDir, entry.name);
        try {
            const stats = await fs.promises.stat(fullPath);
            items.push({
                name: entry.name,
                path: fullPath,
                size: stats.size,
                modified: stats.mtime,
                isDirectory: entry.isDirectory(),
            });
        } catch {
            items.push({
                name: entry.name,
                path: fullPath,
                size: 0,
                modified: new Date(),
                isDirectory: entry.isDirectory(),
            });
        }
    }

    return items.sort((a, b) => a.name.localeCompare(b.name));
}

export async function getContentSummary(): Promise<Record<ContentType, { count: number; items: ContentItem[] }>> {
    const types: ContentType[] = ['cars', 'tracks', 'weather'];
    const summary: Record<string, any> = {};

    for (const type of types) {
        const items = await listContent(type);
        summary[type] = {
            count: items.length,
            items: items.slice(0, 10),
        };
    }

    return summary as Record<ContentType, { count: number; items: ContentItem[] }>;
}

export async function deleteContent(type: ContentType, name: string): Promise<{ ok: boolean; message: string }> {
    const contentDir = getContentDir(type);
    const targetPath = path.join(contentDir, name);

    if (!targetPath.startsWith(contentDir)) {
        return { ok: false, message: 'Invalid path' };
    }

    if (!fs.existsSync(targetPath)) {
        return { ok: false, message: 'Item not found' };
    }

    try {
        const stats = await fs.promises.stat(targetPath);
        if (stats.isDirectory()) {
            await fs.promises.rm(targetPath, { recursive: true });
        } else {
            await fs.promises.unlink(targetPath);
        }
        return { ok: true, message: `Deleted ${name}` };
    } catch (err: any) {
        return { ok: false, message: err.message };
    }
}

export async function uploadSingleFile(type: ContentType, file: Express.Multer.File): Promise<{ ok: boolean; message: string }> {
    const contentDir = await ensureContentDir(type);
    const relativePath = file.originalname.replace(/\\/g, '/');
    const targetPath = resolveSafeContentPath(contentDir, relativePath);

    if (!targetPath) {
        return { ok: false, message: 'Invalid path' };
    }

    if (!isAllowedUpload(relativePath, type)) {
        const ext = path.extname(relativePath);
        return { ok: false, message: `File type not allowed: ${ext || '(no extension)'}` };
    }

    try {
        await fs.promises.mkdir(path.dirname(targetPath), { recursive: true });
        await fs.promises.copyFile(file.path, targetPath);
        await fs.promises.unlink(file.path);
        return { ok: true, message: `Uploaded ${relativePath}` };
    } catch (err: unknown) {
        const message = err instanceof Error ? err.message : 'Upload failed';
        return { ok: false, message };
    }
}

export async function extractZip(type: ContentType, zipPath: string): Promise<{ ok: boolean; message: string; extracted: string[]; errors: string[] }> {
    const contentDir = await ensureContentDir(type);
    const extracted: string[] = [];
    const errors: string[] = [];

    console.log(`[extractZip] Starting extraction for type: ${type}, zip: ${zipPath}`);
    console.log(`[extractZip] Content dir: ${contentDir}`);

    const normalizedZipPath = path.normalize(zipPath);
    if (normalizedZipPath.includes('..')) {
        console.log(`[extractZip] Unsafe zip path (contains ..)`);
        return { ok: false, message: 'Invalid zip path', extracted: [], errors: [] };
    }

    try {
        console.log(`[extractZip] Opening zip file...`);
        const zip = await unzipper.Open.file(zipPath);
        const entries = (zip as any).files || [];
        console.log(`[extractZip] Found ${entries.length} entries in zip`);

        for (const entry of entries) {
            try {
                const entryPath = entry.path;
                if (!entryPath || entryPath.trim() === '') {
                    continue;
                }

                const normalizedPath = entryPath.replace(/\\/g, '/');
                const isDirEntry = entry.isDirectory || normalizedPath.endsWith('/');

                if (isDirEntry) {
                    const targetDir = path.join(contentDir, normalizedPath);
                    const relativePath = path.relative(contentDir, targetDir);
                    if (relativePath.startsWith('..') || relativePath.includes('..')) continue;
                    await fs.promises.mkdir(targetDir, { recursive: true });
                    continue;
                }

                const targetDir = path.join(contentDir, path.dirname(normalizedPath));
                const targetPath = path.join(contentDir, normalizedPath);

                const relativePath = path.relative(contentDir, targetPath);
                if (relativePath.startsWith('..') || relativePath.includes('..')) {
                    console.log(`[extractZip] Skipping unsafe path: ${normalizedPath}`);
                    continue;
                }

                if (!fs.existsSync(targetDir)) {
                    await fs.promises.mkdir(targetDir, { recursive: true });
                }

                const existingStats = await fs.promises.stat(targetPath).catch(() => null);
                if (existingStats?.isDirectory()) {
                    continue;
                }

                const entryStream = entry.stream();
                const writeStream = createWriteStream(targetPath);
                await pipeline(entryStream, writeStream);
                extracted.push(normalizedPath);
                console.log(`[extractZip] Extracted: ${normalizedPath}`);
            } catch (err: any) {
                console.error(`[extractZip] Failed to extract ${entry?.path}: ${err.message}`);
                errors.push(`Failed to extract ${entry?.path}: ${err.message}`);
            }
        }

        await fs.promises.unlink(zipPath).catch(() => {});
        console.log(`[extractZip] Done. Extracted: ${extracted.length}, Errors: ${errors.length}`);
        return {
            ok: true,
            message: `Extracted ${extracted.length} files${errors.length > 0 ? ` with ${errors.length} errors` : ''}`,
            extracted,
            errors
        };
    } catch (err: any) {
        console.error(`[extractZip] Failed to open zip: ${err.message}`);
        return { ok: false, message: err.message, extracted: [], errors: [] };
    }
}

export function getContentPath(type: ContentType): string {
    return getContentDir(type);
}